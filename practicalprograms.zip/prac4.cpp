//WAP to print last and second last digit of an integer
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int num,lst,lst2;
	cout<<"Enter the number\n";
	cin>>num;
	lst=num%10;
	lst2=((num-lst)/10)%10;
	cout<<"\nSecond last digit:: "<<lst2
		<<"\nLast digit:: "<<lst;
	getch();
	return 0;
}
