//WAP to print sum of series S=1-2+3-4+5-6+7........
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int ser;
	int s1,s2;
	s1=s2=0;
	cout<<"S=1-2+3-4+5-6+7.........";
	cout<<"\n\nEnter the num upto which you want to print series sum:\n";
	cin>>ser;
	for(int i=1;i<=ser;i++)            
	{
		if(i%2==0)
		{
			s1+=i;
		}
		else
		{
			s2+=i;
		}
	}
	cout<<"The sum is : "<<s2-s1;
	getch();
	return 0;
}
