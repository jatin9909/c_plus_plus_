//WAP to reverse a number
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int num,rev=0;
	cout<<"Enter a number:\n";
	cin>>num;
	for(;num!=0;)
	{
		rev*=10;
		rev=rev+num%10;
		num/=10;
	}
	cout<<"\nREVERSE :\t"<<rev;
	getch();
	return 0;
}
