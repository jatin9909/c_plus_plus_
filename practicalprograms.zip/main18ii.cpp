//WAP to display fibonacci series using iteration
#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
	int num;
	cout<<"FIBONACCI SERIES(0 1 1 2 3 5 8 13.......)\n"<<"Enter the number upto which you want to print the series:\t";
	cin>>num;
	int ch1,ch2,ch3;
	ch1=0;
	ch2=1;
	if(num<=0)
	{
		cout<<"ABORTING!!! enter positive number!!!";
		exit(0);
	}
	if(num==1)
	{
		cout<<ch1;
		exit(0);
	}
	if(num>=2)
	{
		cout<<ch1<<" "<<ch2<<" ";
		for(int i=1;i<=num-2;i++)
		{
			ch3=ch1+ch2;
			ch1=ch2;
			ch2=ch3;
			cout<<ch3<<" ";
		}
	}
	getch();
	return 0;
}
