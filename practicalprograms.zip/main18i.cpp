//A Combine Program for main 18,19,20
#include<iostream>
#include<conio.h>
using namespace std;
int fib(int);
int Fib(int);
int fact(int);
int Fact(int);
int gcd(int,int);
int Gcd(int,int);
int main()
{
	int num,i;
	cout<<"FIBONACCI SERIES::";
	label:
	cout<<"\nEnter the number of rows:\t\t";
	cin>>num;
	if(num<=0)
	{
		cout<<"\nPlease enter a positive number.";
		goto label;
	}
	cout<<"\nThe fibonacci series is:\n";
	for(i=0;i<num;i++)
	{
		cout<<fib(i)<<"  ";
	}
	return 0;
}
int fib(int x)
{
	if(x==0||x==1)
	return x;
	else 
	return fib(x-1)+fib(x-2);
}
