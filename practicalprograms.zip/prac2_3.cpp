//WAP to find greatest and smallest of the three numbers
#include<iostream>
#include<conio.h>
using namespace std;
int max(int,int,int);
int min(int,int,int);
int main()
{
	int n1,n2,n3,mx,mn;
	cout<<"Enter the first number:\n";
	cin>>n1;
	cout<<"Enter the second number:\n";
	cin>>n2;
	cout<<"Enter the third number:\n";
	cin>>n3;
	mx=max(n1,n2,n3);
	mn=min(n1,n2,n3);
	cout<<"\nMAXIMUM: "<<mx;
	cout<<"\nMINIMUM: "<<mn;
	getch();
	return 0;
}
int max(int x,int y,int z)
{
	if(x>y)
	{
		if(x>z)
		return x;
		else
		return z;
	}
	else
	{ 
		if(y>z)
		return y;
		else 
		return z;
	}
}
int min(int x,int y,int z)
{
	if((x<y)&&(x<z))
		return x;
	if((y<x)&&(y<z))
		return y;
	if((z<y)&&(z<x))
		return z;
}
