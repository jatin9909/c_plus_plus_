//MAIN 24
#include<iostream>
#include<conio.h>
#include<iomanip>
using namespace std;
class Box
{
	private:
			int length,breadth,height;
	public:
			friend class box;
			Box()
			{
				length=0;
				breadth=0;
				height=0;
			}
			Box(int l,int b,int h)
			{
				length=l;
				breadth=b;
				height=h;
			}
			void getdata();
			void putdata();
			void sur();
			void volume();
			void operator++();
			void operator++(int);
			void operator--();
			void check();
			void operator--(int);
			Box operator=(Box &b);
};
class box
{
	public:
			bool func(Box a,Box b)
			{
				if((a.length==b.length)&&(a.breadth==b.breadth)&&(a.height==b.height))
				return true;
				else
				return false;
			}
};
void Box::getdata()
{
	cout<<"\nEnter the length of box:\t";
	cin>>length;
	cout<<"Enter the breadth of box:\t";
	cin>>breadth;
	cout<<"Enter the height of box:\t";
	cin>>height;
}
void Box::check()
{
	if(length==breadth)
	if(length==height)
	cout<<"\nThe cuboid is a cube.\n";
	else cout<<"\nThe cuboid is not a cube.\n";
	else cout<<"\nThe cuboid is not a cube.\n";
}
void Box::putdata()
{
	cout<<"\nLength:"<<setw(10)<<length<<" units";
	cout<<"\nBreadth:"<<setw(9)<<breadth<<" units";
	cout<<"\nHeight:"<<setw(10)<<height<<" units";
}
void Box::sur()
{
	long surf=2*(length*breadth+length*height+breadth*height);
	cout<<"\nThe surface area of the box is:\n"<<surf<<" square units";
}
void Box::volume()
{
	long vol=length*breadth*height;
	cout<<"\nThe volume of the box is:\n"<<vol<<" cubic units";
}
void Box::operator++()
{
	length++;
	breadth++;
	height++;
}
void Box::operator++(int)
{
	++length;
	++breadth;
	++height;
}
void Box::operator--()
{
	length--;
	breadth--;
	height--;
}
void Box::operator--(int)
{
	--length;
	--breadth;
	--height;
}
Box Box::operator=(Box &b)
{ 
	length=b.length;
	breadth=b.breadth;
	height=b.height;
	return Box(length,breadth,height);
}
int main()
{
	Box ob,ob2,ob3;
	cout<<"#***************************************#\n";
	cout<<"#**************##* BOX *##**************#\n";
	cout<<"#***************************************#\n";
	cout<<"Enter the dimensions of the cuboid\n";
	ob.getdata();
	int c;
	do
	{
		cout<<"\n\n\t\t MENU";
		cout<<"\n1). Calculate surface area"
			<<"\n2). Calculate volume"
 			<<"\n3). Overload ++operator (prefix and postfix)"
 			<<"\n4). Overload --operator (prefix and postfix)"
 			<<"\n5). Overload == operator as a friend function"
 			<<"\n6). Overload assignment operator"
 			<<"\n7). Check if it is a cube or cuboid"
 			<<"\n8). EXIT";
 		cout<<"\nEnter your choice:\t";
 		cin>>c;
 		switch(c)
 		{
 			case 1: ob.sur();
 					break;
 			case 2: ob.volume();
 					break;
 			case 3: int ch;
 					cout<<"\n1).POSTFIX"
 						<<"\n2).PREFIX"
 						<<"\nEnter your choice:\t";
 					cin>>ch;
 					if(ch==1)
 					ob++;
 					else if(ch==2)
 					++ob;
 					else
 					cout<<"\nWrong choice!!!";
 					ob.putdata();
 					break;
 			case 4: int chi;
 					cout<<"\n1).POSTFIX"
 						<<"\n2).PREFIX"
 						<<"\nEnter your choice:\t";
 					cin>>chi;
 					if(chi==1)
 					ob--;
 					else if(chi==2)
 					--ob;
 					else
 					cout<<"\nWrong choice!!!";
 					ob.putdata();
					break;
			case 5: cout<<"\nEnter the dimensions of the box to be compared:";
					ob3.getdata();
					box b;
					if(b.func(ob,ob3))
					cout<<"\nThe boxes are equal";
					else
					cout<<"\nThe boxes are unequal";
					break;
 			case 6: ob2=ob;
 					cout<<"\nOther object successfully created!!!\n";
 					ob2.volume();
 					break;
 			case 7: ob.check();
 					break;
 			case 8: cout<<"EXIT!!!";
			 		exit(0);
			default:cout<<"\nWrong choice!!!";
					break;
		 }
 	}
	while(c!=8);
 	return 0;
}
 
