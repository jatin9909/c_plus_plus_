//WAP a macro that swaps two numbers
#include<iostream>
#include<conio.h>
using namespace std;
#define swap(a,b){a=a+b;b=a-b;a=a-b;}
int main()
{
	int num1,num2;
	cout<<"Enter num1:\t";
	cin>>num1;
	cout<<"\nEnter num2:\t";
	cin>>num2;
	swap(num1,num2);
	cout<<"\nnum1=\t"<<num1;
	cout<<"\nnum2=\t"<<num2;
}
