//WAP a program to make a calculator
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int num1,num2;
	char ch,ch1;
	ch1='y';
	cout<<"Enter the first number:\n";
	cin>>num1;
	cout<<"Enter the second number:\n";
	cin>>num2;
	cout<<endl;
	while(ch1=='y')	
	{
		cout<<"Enter operator:\n";
		cin>>ch;
		switch(ch)
		{
			case '+':cout<<"SUM:\t"<<num1+num2;
					 break;
			case '-':cout<<"SUBTRACT:\t"<<num1-num2;
					 break;
			case '*':cout<<"MULTIPLY:\t"<<num1*num2;
					 break;
			case '/':if(num2==0)
					 {
					 	cout<<"Can't divide with ZERO!!!";
					 	break;
					 }
					 else
					 cout<<"DIVIDE:\t"<<num1/num2;
					 break;
			default:cout<<"WRONG CHOICE!!!";
					break;
		}
		cout<<"\nWant to do more operations on the above operands(y/n):\n";
		cin>>ch1;		
	}
}
