//WAP to Display the Sum of the digits of a given Number
#include<iostream>
using namespace std;
#include<conio.h>  	 
int main()
{
	int val, num, sum = 0,pro=1;
	cout << "Enter the number : ";
	cin >>num;
	do
	    {
	    	pro=num%10;
	        sum = sum + num % 10;
	        num = num / 10;
	    }while(num>0);
	cout <<"\nSUM:\t\t"<<sum<<"\nPRODUCT:\t"<<pro;
	getch();
	return 0;
}


