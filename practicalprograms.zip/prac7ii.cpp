//WAP to print pattern like
//1234
//123
//12
//1
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int rows;
	cout<<"Enter the number of rows:\n";
	cin>>rows;
	if(rows<0)
	{
		cout<<"Enter only positive number!!!";
		exit(0);
	}
	cout<<"\nPATTERN:\n";
	for(int i=rows;i>=1;i--)
	{
		for(int j=1;j<=i;j++)
		{
			cout<<j<<" ";
		}
		cout<<endl;
	}
	getch();
	return 0;
}
