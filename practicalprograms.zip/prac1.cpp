//WAP to convert the time in minutes into hours and minutes
#include<iostream>
#include<conio.h>
using namespace std;
void time(int);
int main()
{
	int in;
	cout<<"Enter the time in minutes:\n";
	cin>>in;
	time(in);
	getch();
	return 0;
}
void time(int t)
{
	cout<<endl<<"Hour: "<<t/60<<"hour"<<"\n"<<"Minutes: "<<t%60<<"minutes";
}
