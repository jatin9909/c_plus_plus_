//WAP to display factorial using recursion
#include<iostream>
#include<conio.h>
using namespace std;
int fact(int);
int main()
{
	int num;
	int pro;
	cout<<"Enter the number(0-9):\t";
	cin>>num;
	if(num<0)
	{
		cout<<"ABORTING!!! factorial exist for only positive numbers!!!";
		exit(0);
	}
	else
	cout<<"FACTORIAL:\n"<<fact(num);
	getch();
	return 0;
}
int fact(int x)
{
	if(x==1)
	return 1;
	else
	return x*fact(x-1);	
}
