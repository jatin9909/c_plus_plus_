#include<iostream>
#include<conio.h>
#include<stdio.h>
#include<iomanip>
#include<fstream>
using namespace std;
struct student
{
	int rollno;
	char name[20];
	int c;
	int year;
	int tmarks;
	void getdata()
	{
		cout<<"Enter the Roll no of student:";
		cin>>rollno;
		fflush(stdin);
		cout<<"Enter the Name of the student:";
		cin.get(name,20);
		cout<<"Enter the Class:";
		cin>>c;
		cout<<"Enter the Year:";
		cin>>year;
		cout<<"Enter the Total marks:";
		cin>>tmarks;
	}
	void putdata()
	{
		cout<<"\nRoll no::    "<<rollno;
		cout<<"\nName::       "<<name;
		cout<<"\nClass::      "<<c;
		cout<<"\nYear::       "<<year;
		cout<<"\nTotal Marks::"<<tmarks;
	}
};
int main()
{
	student ob[10];
	char ch;
	int i=0;
	ofstream outfile("main25.txt",ios::binary);
	do
	{
		if(i<10)
		{
		cout<<"Enter the details of student::\n";
		ob[i].getdata();
		outfile.write(reinterpret_cast<char*>(&ob[i]),sizeof(ob[i]));
		i++;
		cout<<"\nEnter more data(y/n)::\t";
		cin>>ch;
		}
		else 
		cout<<"\nNo more objects!!!";
	}while(ch=='y');
	ifstream infile("main25.txt",ios::binary);
	for(int j=0;j<i;j++)
	{
		infile.read(reinterpret_cast<char*>(&ob[j]),sizeof(ob[j]));
		ob[i].putdata();
		cout<<endl;
	}
	return 0;
}
