//WAP to print pattern like
//1
//12
//123
//1234
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int rows;
	cout<<"Enter the number of rows:\n";
	cin>>rows;
	if(rows<0)
	{
		cout<<"Enter only positive number!!!";
		exit(0);
	}
	cout<<"\nPATTERN:\n";
	for(int i=1;i<=rows;i++)
	{
		for(int j=1;j<=i;j++)
		{
			cout<<j<<" ";
		}
		cout<<endl;
	}
	getch();
	return 0;
}
