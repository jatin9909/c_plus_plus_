//WAP to display GCD of two numbers using iteration
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int num1,num2,min;
	cout<<"Enter the first number:\n";
	cin>>num1;
	cout<<"Enter the second number:\n";
	cin>>num2;
	min=num1;
	if(num1<0)
	{
		num1=-num1;
	}
	if(num2<0)
	{
		num2=-num2;
	}
	if(num2<num1)
	{
		min=num2;
	}
	cout<<endl;
	for(int i=min;i>0;i--)
	{
		if((num1%i==0)&&(num2%i==0))
		{
			cout<<"GCD : "<<i;
			break;
		}
	}
	getch();
	return 0;
}
