//WAP to print sum of series S=1+1/2+1/3+1/4+1/5+.....
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int ser;
	float sum=0.0;
	cout<<"S=1+1/2+1/3+1/4+1/5+.....";
	cout<<"\n\nEnter the num upto which you want to print series sum:\n";
	cin>>ser;
	for(float i=1;i<=ser;i++)
	{
		sum+=(1/i);
	}
	cout<<"The sum is : "<<sum;
	getch();
	return 0;
}
