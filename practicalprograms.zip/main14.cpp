//WAP TO CALCULATE THE AREA AND PERIMETER OF A CIRCLE
#include<iostream>
#include<conio.h>
using namespace std;
void circle(float,float&,float&);
int main()
{
	float r,ar,per;
	ar=per=0.0;
	cout<<"Enter the radius(in cm.):\n";
	cin>>r;
	if(r<0.0)
	{
		cout<<"ENTER POSITIVE RADIUS!!!!";
		exit(0);
	}
	circle(r,ar,per);
	cout<<"AREA: "<<ar<<"cm sq";
	cout<<"\nPERIMETER: "<<per<<"cm";
	getch();
	return 0;	
}
void circle(float rad,float& a,float& p)
{
	a=3.14*rad*rad;
	p=6.28*rad;
}
