//WAP to swap two numbers using references
#include<iostream>
#include<conio.h>
using namespace std;
void swap(int&,int&);
int main()
{
	int num1,num2;
	cout<<"Enter first number:\t";
	cin>>num1;
	cout<<"Enter second number:\t";
	cin>>num2;
	cout<<"Before swapping:\n";
	cout<<num1<<"   "<<num2;
	swap(num1,num2);
	cout<<"\nAfter swapping:\n";
	cout<<num1<<"   "<<num2;
	getch();
	return 0;
}
void swap(int& x,int& y)
{
	int temp=x;
	x=y;
	y=temp;
	
}
