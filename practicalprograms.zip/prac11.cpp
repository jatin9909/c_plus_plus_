//WAP to generate a electricity bill
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	float units,ch1,ch2,ch3,ch,am;
	ch1=ch2=ch3=0;
	ch=50;
	cout<<"~~~~~~~~~~~~~~~~~~~\n"
		<<"~ ELECTRICITY BILL~\n"
		<<"~~~~~~~~~~~~~~~~~~~\n";
	cout<<"\n\nFIXED CHARGES = Rs. 50"
		<<"\na).For the first 100 units - 60 paisa per unit"
		<<"\nb).For next 200 units      - 80 paisa per unit"
		<<"\nc).Beyond 300 units        - 90 paisa per unit" 
		<<"\nd).Beyond amount 300 additional 15% is added";
	cout<<"\n\nEnter the units consumed:\n";
	cin>>units;
	for(int i=1;i<=units;i++)
	{
	if(i<=100)
	ch1+=0.60;
	else if((i>100)&&(i<=300))
	ch2+=0.80;
	else
	ch3+=0.90;
	}
	am=ch+ch1+ch2+ch3;
	cout<<"\nTOTAL BILL(without tax) :\tRs. "<<am<<endl;
	if(am>300)
	{
		am+=(am*15)/100;
		cout<<"NET AMOUNT : Rs."<<am<<endl;
	}
	else
		cout<<"NET AMOUNT : Rs."<<am<<endl;
	cout<<"\n\n\t\t\a\t THANK YOU!!!";
	getch();
	return 0;
}
