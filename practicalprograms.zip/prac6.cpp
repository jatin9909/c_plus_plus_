//WAP to reverse a n integer
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int num,reverse=0;
	cout<<"Enter an integer to reverse:\n\n";
	cin>>num;
	for(;num!=0;)
	{
		reverse*=10;
		reverse+=num%10;
		num/=10;	
	}
	cout<<"\n\nReverse integer is:\n\n"<<reverse;
	getch();
	return 0;
}
