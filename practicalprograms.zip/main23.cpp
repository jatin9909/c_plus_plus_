#include<iostream>
#include<conio.h>
#include<cmath>
#include<process.h>
using namespace std;
class triangle
{
	private:
			float s1,s2,s3;
	public:
			void input()
			{
				cout<<"\nEnter side 1 : ";
				cin>>s1;
				cout<<"Enter side 2 : ";
				cin>>s2;
				cout<<"Enter side 3 : ";
				cin>>s3;
			}
			void check()
			{
				if(s1==s2&&s2==s3)
				area(s1);
				else if((s1*s1)==((s2*s2)+(s3*s3)))
				area(s2,s3);
				else if((s2*s2)==((s1*s1)+(s3*s3)))
				area(s1,s3);
				else if((s3*s3)==((s2*s2)+(s1*s1)))
				area(s2,s1);
				else area(s1,s2,s3);
			}
			void operator=(triangle &t)
			{
					s1=t.s1;
					s2=t.s2;
					s3=t.s3;
			}
			int operator==(triangle &t)
			{
				if((s1==t.s1)&&(s2==t.s2)&&(s3==t.s3))
				return 1;
				else
				return 0;
			}
			void area(float,float,float);
			void area(float,float);
			void area(float);
			void show()
			{
					cout<<"\nFIRST SIDE : "<<s1;
					cout<<"\nSECOND SIDE : "<<s2;
					cout<<"\nTHIRD SIDE : "<<s3;
			}
			void checktri()
			{
				if((s1+s2)>s3 && (s2+s3)>s1 && (s3+s1)>s2)
				check();
				else
				cout<<"\nInvalid Triangle!!!\n";
			}
			
			
};

void triangle::area(float a)
{
	cout<<"\n \t ENTERED SIDES FORM AN EQUALARIAL TRIANGE..-_-";
	float ar=a*a*(sqrt(3)/4);
	cout<<"\nArea of the triangle is::"<<ar<<" sq cms\n";
}
void triangle::area(float a,float b,float c)
{
	float ar,s;
	s=(a+b+c)/2;
	ar=sqrt(s*(s-a)*(s-b)*(s-c));
	cout<<"\nArea of the triangle is::"<<ar<<" sq cms\n";
}
void triangle::area(float a,float b)
{
	cout<<"\nArea of the triangle is::"<<(0.5*a*b)<<" sq cms\n";
}

int main()
{
	triangle t1,t2;
	int ch;
	do
	{
		cout<<"\n\t***MENU****";
		cout<<"\n1). Calculate area of the triangle";
		cout<<"\n2). Create a NEW triangle with same dimensions";
		cout<<"\n3). Check equality of two triangles";
		cout<<"\n4). EXIT";
		cout<<"\n\nEnter the choice(1-4):\t";
		cin>>ch;
		switch(ch)
		{
			case 1: t1.input();
					t1.checktri();
					break;
			case 2: t1.input();
					t2=t1;
					cout<<"\nNEW Triangle Dimensions";
					t2.show();
					break;
			case 3: cout<<"\nFor triangle 1\n";
					t1.input();
					cout<<"\nFor triangle 2\n";
					t2.input();
					if(t1==t2)
					cout<<"\nTriangles are equal";
					else 
					cout<<"\nTriangles are not equal";
					break;
			case 4: cout<<"\n Enter To exit..!!!";
					break;
			default:cout<<"\nWRONG CHOICE!!!\n";
					break;
		}
	}
	while(ch!=4);
	return 0;
}
