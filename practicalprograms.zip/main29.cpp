//bubble sorting with pointers(in asc or desc order)
#include<iostream>
#include<conio.h>
using namespace std;
void bsort(int[],int);
void swap(int*,int*);
int main()
{
	int n;
	cout<<"Enter the size of the array:\t";
	cin>>n;
	int a[n];
	cout<<":: Enter the array elements ::\n";
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	bsort(a,n);
	cout<<"\n1).ASC order\n2).DESC order\n";
	int f;
	cout<<"Enter your choice:\t";
	cin>>f;
	cout<<"\nOrdered sequence is::\n";
	if(f==1)
	{
		for(int j=0;j<n;j++)
		{
			cout<<a[j]<<"  ";
		}
	}
	else if(f==2)
	{
		for(int j=n-1;j>=0;j--)
		{
			cout<<a[j]<<"  ";
		}
	}
	else
	cout<<"\n\nWRONG CHOICE!!!!";
	return 0;
}
void bsort(int *ptr,int m)
{
	int j,k;
	for(j=0;j<m-1;j++)
	{
		for(k=j+1;k<m;k++)
		{
			swap(ptr+j,ptr+k);
		}
	}
}
void swap(int *ptr1,int *ptr2)
{
	if(*ptr1>*ptr2)
	{
		int temp=*ptr1;
		*ptr1=*ptr2;
		*ptr2=temp;
	}
}
