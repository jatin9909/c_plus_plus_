//WAP to print * tree
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int rows;
	cout<<"* TREE\n~~~~~~\n";
	cout<<"Enter the number of the rows:\n";
	cin>>rows;
	cout<<"\n�� PATTERN ��\n";
	cout<<endl;
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<(rows-i);j++)
		{
			cout<<" ";
		}
		for(int k=0;k<=i;k++)
		{
			cout<<"*";
		}
		for(int l=i;l>0;l--)
		{
			cout<<"*";
		}
		cout<<"\n";
	}
	cout<<endl;
	getch();
	return 0;
}
