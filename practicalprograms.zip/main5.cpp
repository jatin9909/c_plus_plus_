//PALINDROME
#include<iostream>
#include<conio.h>
#include<cstring>
using namespace std;
void palin(char str1[],int m);
int main()
{
	char str[100];
	cout<<"Enter the string:\n";
	gets(str);
	int l=strlen(str);
	cout<<endl;
	palin(str,l);
	getch();
	return 0;
}
void palin(char str1[],int m)
{
	int flag=0;
	for(int i=0,j=m-1;i<=m/2;i++,j--)
	{
		if(str1[i]!=str1[j])
		{
			flag=1;
		}
	}
	if(flag==0)
	cout<<"The string is a palindrome.";
	else
	cout<<"The string is not a palindrome.";
}
