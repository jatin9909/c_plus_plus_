//WAP to pront pascal's triangle
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int rows;
	cout<<"PASCAL's TRIANGLE\n\n";
	cout<<"Enter the number of the rows:\n";
	cin>>rows;
	cout<<"PATTERN::\n";
	cout<<endl;
	for(int i=0;i<rows;i++)
	{
		for(int j=1;j<(rows-i);j++)
		{
			cout<<" ";
		}
		for(int k=0;k<=i;k++)
		{
			cout<<k+1;
		}
		for(int l=i;l>0;l--)
		{
			cout<<l;
		}
		cout<<"\n";
	}
	cout<<endl;
	getch();
	return 0;
}
