//Wap to print an array in reverse order by using pointers
#include<iostream>
#include<conio.h>
using namespace std;
void reverse(int *ptr);
int size;
int main()
{
	int arr[10];
	cout<<"Enter the size of array:\n";
	cin>>size;
	cout<<"Enter the array elements:\n";
	for(int i=0;i<size;i++)
	{
		cin>>arr[i];
	}
	reverse(arr);
	cout<<"\nArray in reverse order is:\n";
	for(int j=0;j<size;j++)
	{
		cout<<arr[j]<<"  ";
	}
	return 0;
}
void reverse(int *ptr)
{
	int temp;
	for(int i=0,j=size-1;i<size/2;i++,j--)
	{
		temp=*(ptr+i);
		*(ptr+i)=*(ptr+j);
		*(ptr+j)=temp;
			
	}
}
