//WAP a menu driven program to do various operations on strings
#include<iostream>
#include<conio.h>
#include<cstring>
using namespace std;
int main()
{
	string str;
	int l,ch,i;
	cout<<"Enter the string:\n";
	cin>>str[i];
	l=str.size();
	do
	{
		cout<<"\n\n\t\tMENU";
		cout<<"\n1).Show address of each character in string"
			<<"\n2).Concatenate two strings without using strcat() function"
			<<"\n3).Concatenate two strings using strcat() function"
			<<"\n4).Compare two strings"
			<<"\n5).Calculate length of strings using pointers"
			<<"\n6).Convert all lowercase characters to uppercase"
			<<"\n7).Convert all uppercase characters to lowercase"
			<<"\n8).Calculate number of vowels"
			<<"\n9).Reverse the string"
			<<"\n10).EXIT\n";
		cout<<"\nEnter your choice(1-10)::\n";
		cin>>ch;
		switch(ch)
		{
			case 1:
					break;
			case 2:
					break;	
			case 3:
					break;
			case 4:
					break;
			case 5:
					break;
			case 6:
					break;
			case 7:
					break;
			case 8:
					break;
			case 9:	for(i=l-1;i>=0;i--)
					{
						cout<<str[i];	
					}
					break;
			case 10: cout<<"\nEXIT!!!\n";
					 exit(0);
			default:cout<<"\nWRONG CHOICE!!!!\n";
					break;																 		
		}	
	}while(ch!=10);
	getch();
	return 0;
}
