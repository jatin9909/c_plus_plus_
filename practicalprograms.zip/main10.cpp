//WAP to do operations on an 1-D array
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int size,cho,i,max,min,sum;
	sum=0;
	float avg;
	cout<<"Enter the size of array:\t";
	cin>>size;
	int arr[size];
	cout<<"\nEnter the array elements:\n";
	for(i=0;i<size;i++)
	{
		cin>>arr[i];
	}
	do
	{
	cout<<"\n\n\t\tMENU";
	cout<<"\n1).Print the even valued elements"
		<<"\n2).Print the odd valued elements"
		<<"\n3).Calculate and print sum and average"
		<<"\n4).Print the maximum aand minimum of array"
		<<"\n5).Remove the duplicates from the array"
		<<"\n6).Print the array in reverse order"
		<<"\n7).Exit";
	cout<<"\nEnter your choice:\t";
	cin>>cho;
	switch(cho)
	{
		case 1: cout<<"\nEVEN VALUED ELEMENTS ARE:\n";
			   	for(i=0;i<size;i++)
			   	{
			   		if(arr[i]%2==0)
					   cout<<arr[i]<<"  ";	
				}
				getch();
				break;
		case 2: cout<<"\nODD VALUED ELEMENTS ARE:\n";
			   	for(i=0;i<size;i++)
			   	{
			   		if(arr[i]%2!=0)
					   cout<<arr[i]<<"  ";	
				}
				getch();
				break;
		case 3: for(i=0;i<size;i++)
				{
					sum+=arr[i];
				}
				cout<<"\nSUM : "<<sum;
				avg=sum/size;
				cout<<"\nAVERAGE : "<<avg;
				getch();
				break;
		case 4: max=arr[0];
				for(i=0;i<size;i++)
				{
					if(arr[i]>max)
					max=arr[i];
				}
				cout<<"\nMAXIMUM :"<<max;
				min=arr[0];
				for(i=0;i<size;i++)
				{
					if(arr[i]<min)
					min=arr[i];
				}
				cout<<"\nMINIMUM :"<<min;
				getch();
				break;
		case 5: cout<<"\nARRAY AFTER DELETING DUPLICATES IS:\n";
				for(int e=0;e<size;e++)
				{
					for(int er=e+1;er<size;)
					{
						if(arr[e]==arr[er])
						{
							for(int f=er;f<size;f++)
							{
								arr[f]=arr[f+1];
							}
							size--;
							}
							else er++;		
					}	
				} 
				for(int i=0;i<size;i++)
				cout<<arr[i]<<"  ";
				getch();
				break;
		case 6: cout<<"\nREVERSED ARRAY :\n";
				for(i=size-1;i>=0;i--)
				{
					cout<<arr[i]<<"  ";
				}
				getch();
				break;
		case 7: cout<<"\nEXIT!!!";
				break;
		default: cout<<"\nWrong choice!!!";
				 getch();
				 break;
	}
    }while(cho!=7);
	getch();
	return 0;
}
