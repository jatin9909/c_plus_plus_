// MERGE SORT
#include<iostream>
#include<conio.h>>
using namespace std;
int main()
{
	int arr1[100],arr2[100],resarr[200];
	int m,n,i,j,k,t;
	cout<<"MERGE SORTING\n\n";
	cout<<"Enter the size of first array:\t";
	cin>>m;
	cout<<"\nEnter the first array elements:\n";
	for(i=0;i<m;i++)
	{
		cin>>arr1[i];
	}
	cout<<"Enter the size of second array:\t";
	cin>>n;
	t=m+n;
	cout<<"\nEnter the second array elements:\n";
	for(i=0;i<n;i++)
	{
		cin>>arr2[i];
	}
	i=j=k=0;
	for(i=0;i<m;i++)
	{
		resarr[i]=arr1[i];
	}
	for(i=m;i<t;i++)
	{
		resarr[i]=arr2[k++];
	}
	for(i=0;i<t-1;i++)
	{
		for(j=i+1;j<t;j++)
		{
			if(resarr[i]>resarr[j])
			{
				int temp=resarr[i];
				resarr[i]=resarr[j];
				resarr[j]=temp;
			}
		}
	}
	cout<<"\nRESULTANT ARRAY::\n";
	for(i=0;i<t;i++)
	{
		cout<<resarr[i]<<"  ";
	}
	getch();
	return 0;
}
