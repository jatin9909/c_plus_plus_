//WAP to check number is prime or not and print numbers less than 100
#include<iostream>
#include<conio.h>
using namespace std;
void prime(int);
int main() 
{
	int num,flag;
	cout<<"Enter the number :\n";
	cin>>num;
	prime(num);
	getch();
	return 0;
}
void prime(int n)
{
	int flag=0;
	if(n<0)
	{
		cout<<"Only positive!!!";
		exit(0);
	}
	if(n==0)
	{
		cout<<"Not prime!!!";
		exit(0);
	}
	for(int i=2;i<=n/2;i++)
	{
		if(n%i==0)
		{
			flag=1;
			break;
		}
	}
	if(flag==0)
	cout<<"This is prime number.\n";
	else
	cout<<"This is not prime number.\n";
}
