//A Combine Program for main 18,19,20
#include<iostream>
#include<conio.h>
using namespace std;
int fib(int);
int Fib(int);
int fact(int);
int Fact(int);
int gcd(int,int);
int Gcd(int,int);
int main()
{
	int ch,c;
	do
	{
		cout<<"\n\t\tMENU\n";
		cout<<"\n1).Fibonacci series";
		cout<<"\n2).Factorial";
		cout<<"\n3).GCD";
		cout<<"\n4).EXIT";
		cout<<"\n\nEnter your choice:\t\t";
		cin>>ch;
		switch(ch)
		{
			case 1: int num;
					cout<<"\n1).Using recursion"
						<<"\n2).Using iteration"
						<<"\n\nEnter your choice:\t";
					cin>>c;
					if(c==1)
					{
						cout<<"\nEnter the number upto which you want to print series:\t";
						cin>>num;
						cout<<"\nFIBONACCI SERIES::\n";
						for(int i=0;i<num;i++)
						{
							cout<<fib(i)<<"  ";
						}		
					}	
					else if(c==2)
					{
						cout<<"\nEnter the number upto which you want to print series:\t";
						cin>>num;
						cout<<"\nFIBONACCI SERIES::\n";
						for(int i=0;i<num;i++)
						{
							cout<<Fib(i)<<"  ";
						}
					}	
					else
					cout<<"\nWrong choice!!!";
					break;
			case 2: int num1;
					cout<<"\n1).Using recursion"
						<<"\n2).Using iteration"
						<<"\n\nEnter your choice:\t";
					cin>>c;
					if(c==1)
					{
						cout<<"\nEnter the number:\t";
						cin>>num1;
						cout<<"\nFACTORIAL:\t"<<fact(num1);
					}	
					else if(c==2)
					{
						cout<<"\nEnter the number:\t";
						cin>>num1;
						cout<<"\nFACTORIAL:\t"<<Fact(num1);	
					}	
					else
					cout<<"\nWrong choice!!!";
					break;	
			case 3: int x,y;
					cout<<"\n1).Using recursion"
						<<"\n2).Without recursion"
						<<"\n\nEnter your choice:\t";
					cin>>c;
					if(c==1)
					{
						cout<<"\nEnter the first number:";
						cin>>x;
						cout<<"Enter the second number:";
						cin>>y;
						cout<<"\nGCD : "<<gcd(x,y);
					}	
					else if(c==2)
					{
						cout<<"\nEnter the first number:";
						cin>>x;
						cout<<"Enter the second number:";
						cin>>y;
						cout<<"\nGCD : "<<Gcd(x,y);	
					}	
					else
					cout<<"\nWrong choice!!!";
					break;				
			case 4: cout<<"\nEXIT!!!";
					exit(0);
			default:cout<<"\nWrong choice entered!!!";
					break;
		}
		cout<<endl;
	}while(ch!=4);
}
int fib(int x)
{
	if(x==0||x==1)
	return x;
	else 
	return fib(x-1)+fib(x-2);
}
int Fib(int x)
{
	int f1,f2,f;
	if(x==0||x==1)
	return x;
	else
	f1=f=0;
	f2=1;
	for(int i=2;i<=x;i++)
	{
		f=f1+f2;
		f1=f2;
		f2=f;
	}
	return f;
}
int fact(int x)
{
	if(x==1)
	return 1;
	else
	return x*fact(x-1);	
}
int Fact(int x)
{
	int pro=1;
	for(int i=x;i>0;i--)
	{
		pro*=i;
	}
	return pro;
}
int gcd(int a,int b)
{
	if(b==0)
	{
		return a;
	}
	else
	return gcd(b,a%b);
}
int Gcd(int a,int b)
{
	int temp;
	if(a<b)
	{
		temp=a;
		a=b;
		b=temp;
	}
	while(b!=0)
	{
		temp=a%b;
		a=b;
		b=temp;
	}
	return a;
}
