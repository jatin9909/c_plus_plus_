//Wap to copy the contents of one text file into another file, after removing all whitespaces
#include<iostream>
#include<conio.h>
#include<fstream>
#include<string>
using namespace std;
int main()
{
	string str="ank ush\n";
	fstream outfile("main27.txt",ios::in|ios::out);
	for(int i=0;i<str.size();i++)
	{
		outfile.put(str[i]);
	}
	cout<<str;
	cout<<"FILE WRITTEN!!!";
	int j=0;
	fstream infile("main28.txt",ios::in);
	while(infile)
	{
		if(outfile.get(str[j])!=" ")
		{
			infile.put (str[j]);
			cout<<str[j];
			j++;
		}
		else j++;  
    }
	cout<<"\nFILE READ!!!";
	infile.close();
	outfile.close();
	return 0;
}
