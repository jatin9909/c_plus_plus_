//MAIN 25
#include<iostream>
#include<conio.h>
#include<iomanip>
#include<fstream>
using namespace std;
struct student
{
	int rollno;
	char name[20];
	int clas;
	int year;
	int tmarks;
	void getdata()
	{
		cout<<"Enter the Roll no:\n";
		cin>>rollno;
		cout<<"Enter the Name:\n";
		cin>>name;
		cout<<"Enter the Class:\n";
		cin>>clas;
		cout<<"Enter the Year:\n";
		cin>>year;
		cout<<"Enter the Total marks:\n";
		cin>>tmarks;
	}
	void putdata()
	{
		cout<<"\nRoll no::    "<<setw(10)<<rollno;
		cout<<"\nName::       "<<setw(10)<<name;
		cout<<"\nClass::      "<<setw(10)<<clas;
		cout<<"\nYear::       "<<setw(10)<<year;
		cout<<"\nTotal Marks::"<<setw(10)<<tmarks;
	}
};
int main()
{
	student ob[10];
	ifstream infile("main25.txt",ios::in);
	for(int i=0;i<10;i++)
	{
		infile.read(reinterpret_cast<char*>(&ob[i]),sizeof(ob[i]));
		ob[i].putdata();
		cout<<endl;
	}
	return 0;
}
