//WAP to calculate the GCD of two numbers by using recursion
//NOT WORKING YET
#include<iostream>
#include<conio.h>
using namespace std;
int gcd(int m,int n);
int main()
{
	int num1,num2,re;
	cout<<"Enter the first number:\n";
	cin>>num1;
	cout<<"Enter the second number:\n";
	cin>>num2;
	if(num1<0)
	{
		num1=-num1;
	}
	if(num2<0)
	{
		num2=-num2;
	}
	if(num1==0||num2==0)
	{
		cout<<"Zero error!!!";
		exit(0);
	}
	re=gcd(num1,num2);
	cout<<"\nGCD of "<<num1<<" & "<<num2<<" :: "<<re;
	return 0;
}
int gcd(int m,int n)
{
	if(m>n)
	{
		if(n!=0)
		return gcd(m,m%n);
		else return m;
	}
}
