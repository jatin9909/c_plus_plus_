//WAP to display factorial using iteration
#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
	int num;
	double pro=1;
	cout<<"Enter the number(0-9):\t";
	cin>>num;
	if(num<0)
	{
		cout<<"\n\nABORTING!!! factorial exist for only positive numbers!!!";
		exit(0);
	}
	else
	for(int i=num;i>0;i--)
	{
		pro*=i;
	}
	cout<<"FACTORIAL:\n\n"<<pro;
	getch();
	return 0;
}
